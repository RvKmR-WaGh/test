import paramiko
import sys
from ast import literal_eval
lis = literal_eval(sys.argv[1])
cmd = sys.argv[2]
ssh = paramiko.SSHClient()
ssh.load_system_host_keys()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
for host in lis:
	try:
		ssh.connect(host,username='ravikumarmnb', password='ravixyz', timeout=3)
		print "Connected to : %s" % (host)
	    	stdin, stdout, stderr = ssh.exec_command(cmd)
    		print "%s >>>> %s %s" % (host, stdout.readlines(), stderr.readlines())
  	except Exception: 
		print "Could not connect to %s<<<<" % (host)
